<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{exportLengow}prestashop>exportlengow_82b5a57b2835fad00a30bafb01d328b7'] = 'Informations: ';
$_MODULE['<{exportLengow}prestashop>exportlengow_f153d92c82352821bc659e5b8c753288'] = 'URL de votre catalogue produit: ';
$_MODULE['<{exportLengow}prestashop>exportlengow_0392e77d19d8f4c2f2cd5c93ce4dc87c'] = 'URL de votre catalogue produit avec les déclinaisons: ';
$_MODULE['<{exportLengow}prestashop>exportlengow_574e0b7aece74215db65b0ee26ab58da'] = 'Lengow : export de votre catalogue produits';
$_MODULE['<{exportLengow}prestashop>exportlengow_0a739b221caaa9ed4dbc0ef59edc359a'] = 'Lengow est une solution SaaS permettant à un e-commerçant d\'optimiser ses catalogues produits vers les comparateurs de prix, régies d\'affiliation mais aussi marketplaces et sites de Cashback.';
$_MODULE['<{exportLengow}prestashop>exportlengow_7078c3438bb46fdab36587050053cacf'] = 'Le principe est que la solution récupère le catalogue produits du marchand, configure, optimise et tracke les informations des campagnes marchandes afin de restituer à l\'e-commerçant les statistiques sous forme de tableaux de bords et graphiques.';
$_MODULE['<{exportLengow}prestashop>exportlengow_4116f2e6b08ae5aae73ed7f399cf45ee'] = 'Ce processus permet aux e-commerçants d\'optimiser leurs flux et leurs coûts d\'acquisition sur chaque support de diffusion.';
$_MODULE['<{exportLengow}prestashop>exportlengow_9a71923a8dbd55e9f3e4b2225ed7f2dd'] = 'Exportez votre catalogue produits vers la solution Lengow.';
$_MODULE['<{exportLengow}prestashop>exportlengow_4cc7b2483088b9f51e2b7d11603d7bd7'] = 'Etes vous certain de vouloir désinstaller le module Lengow?';
$_MODULE['<{exportLengow}prestashop>exportlengow_1b5e4f9b07ad87029a7f94ce4006b1da'] = 'Le Module Lengow ne doit pas être renomé';
$_MODULE['<{exportLengow}prestashop>exportlengow_365589d7ae6168a24ff2de3c924149ed'] = 'Solution Lengow';
$_MODULE['<{exportLengow}prestashop>exportlengow_2c251c08b2589ac8a4dc78150b423417'] = 'Choisissez vos catégories et produits à exporter: ';
$_MODULE['<{exportLengow}prestashop>exportlengow_fcd47c11a73886a4fe3840db0ba9d6ad'] = 'Arbre des catégories: ';
$_MODULE['<{exportLengow}prestashop>exportlengow_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{exportLengow}prestashop>exportlengow_deb10517653c255364175796ace3553f'] = 'Produit';
$_MODULE['<{exportLengow}prestashop>exportlengow_629709b86fd09c134ba328eeeeef63cc'] = 'Vous êtes client chez Lengow? Veuillez saisir votre identifiant: ';
$_MODULE['<{exportLengow}prestashop>exportlengow_b01bcbd0500cda4c67a727b6cd61754e'] = 'Votre identifiant doit être un entier > 0';
$_MODULE['<{exportLengow}prestashop>exportlengow_bc74aa3ba771ee7e1adf49a9430083ff'] = 'Choisissez la langue à utiliser dans l\'export: ';
$_MODULE['<{exportLengow}prestashop>exportlengow_5e9df908eafa83cb51c0a3720e8348c7'] = 'Cocher tous les produits';
$_MODULE['<{exportLengow}prestashop>exportlengow_9747d23c8cc358c5ef78c51e59cd6817'] = 'Décocher tous les produits';
$_MODULE['<{exportLengow}prestashop>exportlengow_07e5a123264f67e171d0493ba8774875'] = 'En indiquant votre identifiant Lengow, vous pourrez ainsi placer le tag de conversion automatiquement sur votre page de confirmation de commande.';

