function formatSearch(row) {
	return row[2] + ' > ' + row[1];
}

function redirectSearch(event, data, formatted) {
	$('#search_query').val(data[1]);
	document.location.href = data[3];
}

$('document').ready( function() {
	$("#search_query_menu").autocomplete(
		baseDir + 'search.php', {
		minChars: 3,
		max:10,
		width:500,
		scroll: false,
		formatItem:formatSearch,
		extraParams:{ajaxSearch:1,id_lang:id_lang}
	}).result(redirectSearch)
});