<?php
require_once dirname(__FILE__) . '/../../../config/config.inc.php';
require_once dirname(__FILE__) . '/../../../init.php';

header('Content-type: text/css; charset=utf-8;');

echo '.sf-contener, .sf-menu {width:' . Configuration::get('MENU_WIDTH') . 'px;}' . "\n";
echo '.sf-menu {line-height:' . Configuration::get('MENU_HEIGHT') . '}' . "\n";
echo '.sf-menu li:hover ul, .sf-menu li.sfHover ul {z-index:' . Configuration::get('MENU_INDEX') . ';}' . "\n";
echo '.sf-menu a {font-size:' . Configuration::get('MENU_TEXT_SIZE') . 'px}'."\n";
echo '.sf-menu span {vertical-align: ' . Configuration::get('MENU_TEXT_VERTICAL') . 'px}'."\n";
echo '.sf-menu li li, .sf-menu li li li {background:#' . Configuration::get('MENU_ITEM_COLOR') . ';}'."\n";
echo '.sf-menu ul li:hover, .sf-menu ul li.sfHover, .sf-menu ul li a:focus, .sf-menu ul li a:hover, .sf-menu ul li a:active {background:#' . Configuration::get('MENU_ITEM_HOVER_COLOR') . ';}'."\n";

// ITEM SIZE
echo '.sf-menu ul {width: ' . Configuration::get('MENU_ITEM_SIZE') . 'em;}' . "\n";
echo 'ul.sf-menu li li:hover ul, ul.sf-menu li li.sfHover ul {left: ' . Configuration::get('MENU_ITEM_SIZE') . 'em;}' . "\n";
echo 'ul.sf-menu li li:hover ul, ul.sf-menu li li.sfHover ul {left: ' . Configuration::get('MENU_ITEM_SIZE') . 'em;}' . "\n";
echo 'ul.sf-menu li li li:hover ul, ul.sf-menu li li li.sfHover ul {left: ' . Configuration::get('MENU_ITEM_SIZE') . 'em;}' . "\n";

// TEXT
$styles = 'color:#' . Configuration::get('MENU_TEXT_COLOR') . ';';
if (Configuration::get('MENU_TEXT_BOLD')) {
  $styles .= 'font-weight:bold;';
}
if (Configuration::get('MENU_TEXT_ITALIC')) {
  $styles .= 'font-style:italic;';
}
if (Configuration::get('MENU_TEXT_UNDERLINE')) {
  $styles .= 'text-decoration:underline;';
}
echo '.sf-menu a, .sf-menu a:visited  {' . $styles . '}' . "\n";

// TEXT OVER
$styles = 'color:#' . Configuration::get('MENU_TEXT_OVER_COLOR') . ';';
if (Configuration::get('MENU_TEXT_OVER_BOLD')) {
  $styles .= 'font-weight:bold;';
}
if (Configuration::get('MENU_TEXT_OVER_ITALIC')) {
  $styles .= 'font-style:italic;';
}
if (Configuration::get('MENU_TEXT_OVER_UNDERLINE')) {
  $styles .= 'text-decoration:underline;';
}
echo '.sf-menu a:hover  {' . $styles . '}' . "\n";
?>