<?php
require_once dirname(__FILE__) . '/../../config/config.inc.php';
require_once dirname(__FILE__) . '/../../init.php';
require_once dirname(__FILE__) . '/menu.class.php';

$img = imageCreateFromGif(dirname(__FILE__) . '/gfx/menu/menu_orig.gif');
if (isset($_GET['color']) && strlen($_GET['color']) === 6) {
  Menu::colorize($img, $_GET['color']);
}
if (isset($_GET['preview'])) {
  header('Content-type: image/gif');
  imageGif($img);
}

imagedestroy($img);
?>